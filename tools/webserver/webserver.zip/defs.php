<?php

$webserver="http://192.168.115.123:8080";

?>