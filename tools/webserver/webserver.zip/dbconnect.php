<?php
$db = new mysqli("localhost", "addressmaster", "pw4am", "phonebook_innovaphone");
?>